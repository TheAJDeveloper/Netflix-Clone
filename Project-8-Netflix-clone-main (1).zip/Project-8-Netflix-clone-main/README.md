# Project-8-Netflix-clone

# here below live link view of this projects
https://rushikeshborude.github.io/Project-8-Netflix-clone/




# this is a images of projects 

![Screenshot (13896)](https://github.com/RushikeshBorude/Project-8-Netflix-clone/assets/86228914/d6ed9c87-1a00-4760-a254-bda6b538b681)



![Screenshot (13879)](https://github.com/RushikeshBorude/Project-8-Netflix-clone/assets/86228914/56abd4ba-479f-4164-9fa6-b98d8b093fd4)




![Screenshot (13880)](https://github.com/RushikeshBorude/Project-8-Netflix-clone/assets/86228914/26e15854-2559-43a6-affc-c7aa5f92ab4b)





![Screenshot (13881)](https://github.com/RushikeshBorude/Project-8-Netflix-clone/assets/86228914/3e49e75e-70b2-48b9-bf54-8fe54ff4e63b)





![Screenshot (13882)](https://github.com/RushikeshBorude/Project-8-Netflix-clone/assets/86228914/dff4f29a-b269-4c8a-a599-1ad733748bc1)





![Screenshot (13883)](https://github.com/RushikeshBorude/Project-8-Netflix-clone/assets/86228914/f2236097-8148-49ad-9c01-1d2392635e2d)





![Screenshot (13884)](https://github.com/RushikeshBorude/Project-8-Netflix-clone/assets/86228914/928429ef-fa9d-4334-9e7b-14d34d7b5959)
